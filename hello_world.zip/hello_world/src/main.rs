use std::fs::File;
use sys_locale::get_locale;
use gettext_ng::Catalog;
use std::path::Path;
use current_platform::{CURRENT_PLATFORM, COMPILED_ON};

fn main() {
    const VERSION: &str = env!("CARGO_PKG_VERSION");
    let current_locale = get_locale().unwrap_or_else(|| String::from("en-US"));
    let filename = format!("{}.mo", current_locale);

    let file_path = format!("{current_locale}.mo");
    let path = Path::new(&file_path);
    if path.exists() {
        println!("LanguageFile: {file_path} exists!");

        let f = File::open(filename).expect("could not open the catalog");
        let catalog = Catalog::parse(f).expect("could not parse the catalog");

        println!("Platform: {} Program was compiled on {}", CURRENT_PLATFORM,COMPILED_ON);
        println!("The locale is {}", current_locale);
        println!("Program v{}", VERSION);
        println!("");
        println!("{}", catalog.gettext("Hello World!"));
        println!("");
        println!("{}", catalog.gettext("Welcome to Rust"));
        println!("");   


    } else {
        println!("File: {file_path} does not exist! Program abort");
    }

}
