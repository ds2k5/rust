// Quelle: https://www.youtube.com/@Programmierenlernen

mod env;
use reqwest::blocking::get;
use serde_json::{ Value, from_str };
use chrono::NaiveDateTime;
use current_platform::{CURRENT_PLATFORM, COMPILED_ON};
use sys_locale::get_locale;
use std::path::Path;
use gettext_ng::Catalog;
use std::fs::File;

fn main(){
    const VERSION: &str = env!("CARGO_PKG_VERSION");
    const NAME: &str = env!("CARGO_PKG_NAME");
    let current_locale = get_locale().unwrap_or_else(|| String::from("en-US"));
    let pattern = std::env::args().nth(1).expect("no pattern given. run weather cityname");
    let city = pattern;
    let filename = format!("{}.mo", current_locale);

    let file_path = format!("{current_locale}.mo");
    let path = Path::new(&file_path);
    if path.exists() {
        println!("LanguageFile: {file_path} exists!");
        let f = File::open(filename).expect("could not open the catalog");
        let catalog = Catalog::parse(f).expect("could not parse the catalog");


    println!("Platform: {} Program was compiled on {}", CURRENT_PLATFORM, COMPILED_ON);
    println!("The locale is {}\n", current_locale);
    println!("{} v{}\n", NAME, VERSION);
    println!("The locale is {}", current_locale);
    println!("{} {}", catalog.gettext("\nThe weather in"), city);

    let api_key = env::API_KEY;
    let url = format!("https://api.openweathermap.org/data/2.5/weather?q={}&appid={}", city, api_key);
    let response = get(url).unwrap();
    let response_text = response.text().unwrap();
    let json: Value = from_str(&response_text).expect("JSON was not well-formatted");

    let temp_kelvin = json["main"]["temp"].as_f64().unwrap();
    let temp_celsius = temp_kelvin - 273.15;

    let temp_kelvin_min = json["main"]["temp_min"].as_f64().unwrap();
    let temp_celsius_min = temp_kelvin_min - 273.15;

    let temp_kelvin_max = json["main"]["temp_max"].as_f64().unwrap();
    let temp_celsius_max = temp_kelvin_max - 273.15;


    let humidity: f64 = json["main"]["humidity"].as_f64().unwrap();
    let pressure: f64 = json["main"]["pressure"].as_f64().unwrap();
    let windspeed: f64 = json["wind"]["speed"].as_f64().unwrap();
    let windspeed_kmh: f64 = windspeed * 4.0 - (windspeed * 4.0 * 0.1); 
    let windspeed_gust: f64 = json["wind"]["gust"].as_f64().unwrap();
    let windspeed_gust_kmh: f64 = windspeed_gust * 4.0 - (windspeed_gust * 4.0 * 0.1); 

    let clouds: f64 = json["clouds"]["all"].as_f64().unwrap();

    let sunrise: i64 = json["sys"]["sunrise"].as_i64().unwrap();
    let sunrise_unix_time = sunrise;
    let sunrise_rust_time = NaiveDateTime::from_timestamp_opt(sunrise_unix_time, 0).unwrap();
    let sunrise_human_time = sunrise_rust_time.format("%Y-%m-%d %H:%M:%S");


    let sunset: i64 = json["sys"]["sunset"].as_i64().unwrap();
    let sunset_unix_time = sunset;
    let sunset_rust_time = NaiveDateTime::from_timestamp_opt(sunset_unix_time, 0).unwrap();
    let sunset_human_time = sunset_rust_time.format("%Y-%m-%d %H:%M:%S");


    println!("{} {} °C", catalog.gettext("Current"), temp_celsius.round());    
    println!("{} {} °C", catalog.gettext("minimum"), temp_celsius_min.round());
    println!("{} {} °C", catalog.gettext("maximum"), temp_celsius_max.round());

    println!("{} {} %", catalog.gettext("Air humidity"), humidity);
    println!("{} {} pa", catalog.gettext("Air pressure"), pressure);
    println!("{} {} m/s / {} km/h", catalog.gettext("Wind"), windspeed, windspeed_kmh);
    println!("{} {} m/s / {} km/h", catalog.gettext("Wind gusts"), windspeed_gust, windspeed_gust_kmh);
    println!("{} {} %", catalog.gettext("Clouds"), clouds);
    println!("\n");
    println!("{} {} UTC / CET = UTC+1 ", catalog.gettext("Sunrise"), sunrise_human_time);
    println!("{} {} UTC / CET = UTC+1 ", catalog.gettext("Sunset"), sunset_human_time);
    println!("\n");

} else {
    println!("File: {file_path} does not exist! Program abort");
}

}