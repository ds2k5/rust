// https://server.duinocoin.com/balances.json

use reqwest::blocking::get;
use serde_json::{ Value, from_str };
use current_platform::{CURRENT_PLATFORM, COMPILED_ON};
use sys_locale::get_locale;
use std::path::Path;
use gettext_ng::Catalog;
use std::fs::File;
use std::net::{SocketAddr, TcpStream};

fn main(){
    let addrs = [
        SocketAddr::from(([8, 8, 8, 8], 53)),
        SocketAddr::from(([51, 15, 127, 80], 80)),
    ];
    if let Ok(_stream    ) = TcpStream::connect(&addrs[..]) {
        println!("Connected to the server!");

    const VERSION: &str = env!("CARGO_PKG_VERSION");
    const NAME: &str = env!("CARGO_PKG_NAME");
    let current_locale = get_locale().unwrap_or_else(|| String::from("en-US"));
    let pattern = std::env::args().nth(1).expect("no pattern given. run duinocoin_checker USERNAME");
    let username = pattern;
    let filename = format!("{}.mo", current_locale);

    let file_path = format!("{current_locale}.mo");
    let path = Path::new(&file_path);
    if path.exists() {
        println!("LanguageFile: {file_path} exists!");
        let f = File::open(filename).expect("could not open the catalog");
        let catalog = Catalog::parse(f).expect("could not parse the catalog");


    println!("Platform: {} Program was compiled on {}", CURRENT_PLATFORM, COMPILED_ON);
    println!("The locale is {}\n", current_locale);
    println!("{} v{}\n", NAME, VERSION);

    let url = format!("https://server.duinocoin.com/balances.json");
    let response = get(url).unwrap();
    let response_text = response.text().unwrap();
    let json: Value = from_str(&response_text).expect("JSON was not well-formatted");
    
    let walletvalue = json[username].as_f64().unwrap();

    println!("{} {}", catalog.gettext("Coins"), walletvalue);
    println!("\n");

} else {
    println!("File: {file_path} does not exist! Program abort");
}


} else {
    println!("Couldn't connect to server...check your Internet connection!");
}


}